//
//  CollectionViewCell.swift
//  BlackJack
//
//  Created by David Aghassi on 2/11/16.
//  Copyright © 2016 CBC. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
  @IBOutlet weak var image: UIImageView!
}
